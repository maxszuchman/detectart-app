package com.experta.detectart.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.experta.detectart.MainActivity;
import com.google.firebase.auth.FirebaseAuth;

public class LogOutActivity extends AppCompatActivity {

    private FirebaseAuth firebaseAuth;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);

         firebaseAuth = FirebaseAuth.getInstance();
         firebaseAuth.signOut();
         finish();
         startActivity(new Intent(LogOutActivity.this, MainActivity.class));
    }
}
